
<img src="{{ url('images/ads/14') }}" alt="Image Product"> 
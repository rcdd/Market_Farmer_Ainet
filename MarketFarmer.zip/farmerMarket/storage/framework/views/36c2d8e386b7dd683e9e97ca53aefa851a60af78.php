<?php if(count($comments) > 0): ?>
    <?php foreach($comments as $comment): ?>
	    <div class="row col-md-12">
	    	<div class="row">
		        <div class="col-md-2">
		            <label class="control-label" for="user">User: </label>
		            <?php echo e($comment->user->name); ?>

		        </div>
		        <div class="col-md-4">
		            <label class="control-label" for="date">Date: </label>
		            <?php echo e($comment->created_at); ?>

		        </div>
		    </div>
	     <div class="row">
	        <div class="col-md-6">
	            <label class="control-label" for="user">Mensage: </label>
	            <?php echo e($comment->comment); ?>

	        </div>
	        <div class="col-md-2">
	            <button data-toggle="modal" data-target="#replayComment" data-id="<?php echo e($comment->id); ?>" class="replay btn btn-warning">
	                    <i class="fa fa-mail-reply"></i> Replay
	            </button>
	            <?php if(Auth::user()->admin): ?>
	            <a href="<?php echo e(url('/comment/delete/' . $comment->id)); ?>"><button class="replay btn btn-danger">
	                    <i class="fa fa-close"></i> Delete
	            </button></a>
	            <?php endif; ?>
	        </div>
	      </div>
	      <hr width=80% align=left>
	    </div>
	    <?php if(count($comment->hasReplay) > 0): ?>
	        <?php foreach($comment->hasReplay as $com): ?>
				<div class="row col-md-offset-1">
			    	<div class="row ">
				        <div class="col-md-2">
				            <label class="control-label" for="user">User: </label>
				            <?php echo e($com->user->name); ?>

				        </div>
				        <div class="col-md-4">
				            <label class="control-label" for="date">Date: </label>
				            <?php echo e($com->created_at); ?>

				        </div>
				    </div>
				     <div class="row">
				        <div class="col-md-6">
				            <label class="control-label" for="user">Mensage: </label>
				            <?php echo e($com->comment); ?>

				        </div>
				        <?php if(Auth::user()->admin): ?>
				        <div class="col-md-2">
							<a href="<?php echo e(url('/comment/delete/' . $com->id)); ?>"><button class="replay btn btn-danger">
	                    	<i class="fa fa-close"></i> Delete
	            			</button></a>
				        </div>
				        <?php endif; ?>
				    </div>
				     
				    <br />
			      	<hr width=80% align=left>
			    </div>
	        <?php endforeach; ?>
	    <?php endif; ?>
    <?php endforeach; ?>
<?php else: ?>
    No comments.. Be the First :)
<?php endif; ?>
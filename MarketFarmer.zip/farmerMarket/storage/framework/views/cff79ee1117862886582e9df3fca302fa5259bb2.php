<li>
    <?php echo e($comment->comment); ?>

    <?php if(count($comment->children) > 0): ?>
        <ul>
        	<?php /*<?php echo $__env->renderEach('advertisements.comments_replay', $comment->children, 'comment'); ?>*/ ?>
        </ul>
    <?php endif; ?>
</li>
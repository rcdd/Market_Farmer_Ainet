
<img src="<?php echo e(url('images/ads/14')); ?>" alt="Image Product"> 
<form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/comment/new')); ?>">
    <?php echo e(csrf_field()); ?>

    <label class="control-label" for="message">Comment:</label>
    <p><textarea name="message" id="message"></textarea></p>
    <input type="submit" class="btn btn-success" name="submit">
</form>